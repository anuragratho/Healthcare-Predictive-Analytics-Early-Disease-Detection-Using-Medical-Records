import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the file
df = pd.read_csv('/Users/anurag/Downloads/medical_data_analysis.csv', sep='\t', header=None, names=["Symptom", "Count"])

# Basic bar chart
plt.figure(figsize=(12, 6))
sns.barplot(x="Symptom", y="Count", data=df.sort_values(by="Count", ascending=False))
plt.xticks(rotation=45)
plt.title("Symptom Frequency Analysis")
plt.tight_layout()
plt.show()
